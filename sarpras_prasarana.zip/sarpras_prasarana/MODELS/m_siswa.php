<?php
class M_Siswa {
    private $db;

    public function __construct($koneksi) {
        $this->db = $koneksi;
    }

    public function countSiswa() {
        $query = "SELECT COUNT(*) AS total FROM siswa";
        $result = mysqli_query($this->db, $query);
        $row = mysqli_fetch_assoc($result);
        return (int)($row['total'] ?? 0);
    }

    public function getSiswa($limit = null, $offset = 0) {
        $query = "SELECT * FROM siswa ORDER BY CAST(nis AS UNSIGNED) ASC, nis ASC";

        if ($limit !== null) {
            $query .= " LIMIT " . (int)$limit . " OFFSET " . (int)$offset;
        }

        $result = mysqli_query($this->db, $query);
        $data = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }
        return $data;
    }

    public function getSiswaByNis($nis) {
        $query = "SELECT * FROM siswa WHERE nis = '$nis' LIMIT 1";
        $result = mysqli_query($this->db, $query);
        return mysqli_fetch_assoc($result);
    }

    public function tambahSiswa($nis, $namaSiswa, $kelas, $jurusan, $jenisKelamin, $password) {
        $query = "INSERT INTO siswa (nis, nama_siswa, kelas, jurusan, jenis_kelamin, password)
                  VALUES ('$nis', '$namaSiswa', '$kelas', '$jurusan', '$jenisKelamin', '$password')";
        return mysqli_query($this->db, $query);
    }

    public function updateSiswa($nis, $namaSiswa, $kelas, $jurusan, $jenisKelamin, $password) {
        $query = "UPDATE siswa SET
                    nama_siswa = '$namaSiswa',
                    kelas = '$kelas',
                    jurusan = '$jurusan',
                    jenis_kelamin = '$jenisKelamin',
                    password = '$password'
                  WHERE nis = '$nis'";
        return mysqli_query($this->db, $query);
    }

    public function hapusSiswa($nis) {
        $query = "DELETE FROM siswa WHERE nis = '$nis'";
        return mysqli_query($this->db, $query);
    }
}
?>
